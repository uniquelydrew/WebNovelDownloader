from playwright.sync_api import sync_playwright
import time

from utils.rotating_logger import LineRotatingJSONLogger


class PlaywrightDiscoveryService:

    def __init__(self):
        self.logger = LineRotatingJSONLogger("logs/discovery.log")

    def load(self, url: str) -> str:
        self.logger.log("discovery", "browser_launch", {"url": url})

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)
            context = browser.new_context()
            page = context.new_page()

            page.goto(url, timeout=60000)
            self.logger.log("discovery", "page_loaded")

            page.wait_for_selector(".MuiAccordion-root", timeout=60000)
            self.logger.log("discovery", "accordion_detected")

            expanded = self._expand_all(page)
            self.logger.log("discovery", "volumes_expanded", {"count": expanded})

            time.sleep(1.5)
            html = page.content()

            self.logger.log("discovery", "dom_captured", {"size": len(html)})

            browser.close()
            self.logger.log("discovery", "browser_closed")

            return html

    def _expand_all(self, page):
        buttons = page.query_selector_all("button[aria-expanded='false']")
        expanded = 0

        for b in buttons:
            try:
                b.click()
                expanded += 1
                time.sleep(0.05)
            except Exception as e:
                self.logger.log("discovery", "expand_error", {"error": str(e)})

        return expanded
