import sys
import asyncio

# Windows: force selector loop policy (Twisted AsyncioSelectorReactor compatibility)
if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# Twisted reactor install is safe; GUI itself doesn't run Twisted now, but Scrapy may be imported in subprocess.
from twisted.internet import asyncioreactor
try:
    asyncioreactor.install()
except Exception:
    # If already installed, ignore
    pass

from PySide6.QtWidgets import QApplication
from gui.main_window import MainWindow

def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
