from __future__ import annotations

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QComboBox, QMessageBox, QProgressBar, QTreeWidget,
    QTreeWidgetItem, QTextEdit
)

from services.discovery_service import DiscoveryService
from services.subprocess_worker import SubprocessCrawlWorker


class DiscoveryWorker(QThread):
    finished_html = Signal(object)
    error = Signal(str)

    def __init__(self, service, url):
        super().__init__()
        self.service = service
        self.url = url

    def run(self):
        try:
            series = self.service.load_series_from_url(self.url)
            self.finished_html.emit(series)
        except Exception as e:
            self.error.emit(f"{type(e).__name__}: {e}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WebNovelScraper")
        self.resize(820, 640)

        self.discovery = DiscoveryService()
        self.series = None

        self._build_ui()

    def _build_ui(self):
        root = QWidget()
        main = QVBoxLayout()

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Index URL:"))
        self.url_input = QLineEdit()
        row1.addWidget(self.url_input, 1)
        self.load_btn = QPushButton("Load")
        self.load_btn.clicked.connect(self._load_index)
        row1.addWidget(self.load_btn)
        main.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Format:"))
        self.format_select = QComboBox()
        self.format_select.addItems(["epub", "pdf"])
        row2.addWidget(self.format_select)

        row2.addWidget(QLabel("Export Dir:"))
        self.dir_input = QLineEdit()
        row2.addWidget(self.dir_input, 1)

        self.browse_btn = QPushButton("Browse...")
        self.browse_btn.clicked.connect(self._select_directory)
        row2.addWidget(self.browse_btn)

        self.export_btn = QPushButton("Export Selected")
        self.export_btn.setEnabled(False)
        self.export_btn.clicked.connect(self._export_selected)
        row2.addWidget(self.export_btn)
        main.addLayout(row2)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Volumes / Chapters"])
        self.tree.itemChanged.connect(self._on_item_changed)
        main.addWidget(self.tree, 1)

        self.progress = QProgressBar()
        main.addWidget(self.progress)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        main.addWidget(self.log, 1)

        root.setLayout(main)
        self.setCentralWidget(root)

    def _select_directory(self):
        directory = QFileDialog.getExistingDirectory(self, "Select Export Directory")
        if directory:
            self.dir_input.setText(directory)

    def _load_index(self):
        url = self.url_input.text().strip()
        if not url:
            QMessageBox.warning(self, "Error", "Please enter a URL.")
            return

        self.load_btn.setEnabled(False)
        self.worker = DiscoveryWorker(self.discovery, url)
        self.worker.finished_html.connect(self._on_loaded)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_loaded(self, series):
        self.series = series
        self._populate_tree()
        self.export_btn.setEnabled(True)
        self.load_btn.setEnabled(True)

    def _on_error(self, msg):
        QMessageBox.critical(self, "Error", msg)
        self.load_btn.setEnabled(True)

    def _populate_tree(self):
        self.tree.clear()
        root = QTreeWidgetItem([self.series.title])
        root.setFlags(root.flags() | Qt.ItemIsUserCheckable)
        root.setCheckState(0, Qt.Unchecked)
        root.setData(0, Qt.UserRole, {"type": "series"})
        self.tree.addTopLevelItem(root)

        for vol in self.series.volumes:
            vitem = QTreeWidgetItem([vol.title])
            vitem.setFlags(vitem.flags() | Qt.ItemIsUserCheckable)
            vitem.setCheckState(0, Qt.Unchecked)
            vitem.setData(0, Qt.UserRole, {"type": "volume", "volume_index": vol.index, "volume_title": vol.title})
            root.addChild(vitem)

            for cref in vol.chapters:
                citem = QTreeWidgetItem([cref.title])
                citem.setFlags(citem.flags() | Qt.ItemIsUserCheckable)
                citem.setCheckState(0, Qt.Unchecked)
                citem.setData(0, Qt.UserRole, {
                    "type": "chapter",
                    "volume_index": vol.index,
                    "volume_title": vol.title,
                    "chapter_index": cref.index,
                    "chapter_title": cref.title,
                    "url": cref.url,
                })
                vitem.addChild(citem)

        root.setExpanded(True)

    def _on_item_changed(self, item, column):
        if item.data(0, Qt.UserRole).get("type") in ("series", "volume"):
            for i in range(item.childCount()):
                item.child(i).setCheckState(0, item.checkState(0))

    def _collect_selection(self):
        chapters = []
        root = self.tree.topLevelItem(0)

        def walk(node):
            data = node.data(0, Qt.UserRole)
            if data.get("type") == "chapter" and node.checkState(0) == Qt.Checked:
                chapters.append(data)
            for i in range(node.childCount()):
                walk(node.child(i))

        walk(root)
        return {
            "series_title": self.series.title,
            "chapters": chapters,
            "total_chapters": len(chapters),
        }

    def _export_selected(self):
        payload = self._collect_selection()
        if payload["total_chapters"] == 0:
            QMessageBox.warning(self, "Error", "No chapters selected.")
            return

        worker = SubprocessCrawlWorker(payload, self.dir_input.text().strip(), self.format_select.currentText())
        worker.start()
